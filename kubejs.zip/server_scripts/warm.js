// priority: 0

// Visit the wiki for more info - https://kubejs.com/

console.info('THE ***NETHER*** IS SUPPOSED TO BE ***HOT***')

ServerEvents.tags('worldgen/biome', event =>{
    event.removeAllTagsFrom('pyrellium:frostburn_valley')
})