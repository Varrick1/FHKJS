ServerEvents.recipes(event => {
//DAIFUKU
function daiFlavor(output, flavorInput, flavorInput2) {
        event.shaped(output, [
            ' F ',
            'RGR',
            'SWS'
        ], {
            F: flavorInput,
            S: 'minecraft:sugar',
            G: flavorInput2,
            R: '#c:crops/rice',
            W: '#c:water_bottles'
        })
    }

    daiFlavor('fh:anko_daifuku', 'minecraft:red_dye', 'croptopia:blackbean')
    daiFlavor('fh:anko_strawberry_daifuku', 'croptopia:strawberry', 'croptopia:blackbean')
    daiFlavor('fh:coffee_daifuku','#fh:coffee_beans','minecraft:air')
    daiFlavor('fh:creme_caramel_daifuku','#fh:milk','croptopia:caramel')
    daiFlavor('fh:green_tea_daifuku','herbalbrews:dried_green_tea','herbalbrews:green_tea_leaf')
    daiFlavor('fh:mame_daifuku','croptopia:blackbean','vegandelight:soybean')
    daiFlavor('fh:sesame_daifuku','supplimentaries:flax_seeds','supplimentaries:flax_seeds')
    daiFlavor('fh:strawberry_daifuku','croptopia:strawberry','minecraft:air')
    daiFlavor('fh:taro_daifuku','trailandtales_delight:pitcher_taro','minecraft:air')
    daiFlavor('fh:ume_daifuku','croptopia:plum','minecraft:air')


//DANGO

//function danFlavor(output, flavorInput, flavorInput2, flavorInput3) {
//      event.shaped(output, [
//            'FRS',
//            'GPW',
//            'T  ' 
//        ], {
//            F: flavorInput,
//            S: 'minecraft:sugar',
//            G: flavorInput2,
//            R: flavorInput3,
//            W: '#c:water_bottles'
//            P: 'croptopia:rice'
//        })
//    }

//    danFlavor('fh:', '', '', '')

})