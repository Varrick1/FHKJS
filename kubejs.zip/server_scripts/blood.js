ServerEvents.tags('item', event => {
    event.add('fh:blood', 'fh:blood_bottle')
})